from setuptools import setup

setup(name='prob_dist_ap',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['prob_dist_ap'],
      zip_safe=False)
